import Navbar from "@/components/navbar"
import ArticleContent from "@/components/article-content"
import DownloadCard from "@/components/download-card"
import Footer from "@/components/footer"

export default function Home() {
  // Sample article data
  const article = {
    title: "The Lost Manuscript",
    author: "Eleanor Blackwood",
    date: "May 6, 1925",
    content: [
      "In the dusty corners of an old library, hidden between volumes of forgotten lore, I discovered a manuscript that would change everything we know about ancient civilizations.",
      "The parchment, yellowed with age and fragile to the touch, contained symbols and diagrams unlike anything scholars had documented before. It appeared to be a detailed account of astronomical observations, predating modern understanding by centuries.",
      "What makes this discovery particularly fascinating is the precision with which celestial events were predicted. The author, whose identity remains a mystery, had calculated solar eclipses with remarkable accuracy.",
      "Further analysis revealed references to a lost city, buried beneath the sands of time. Could this be the legendary Atlantis that has eluded explorers for generations?",
      "Experts from around the world have begun the painstaking process of translation, hoping to unlock the secrets held within these ancient pages.",
    ],
    images: [
      {
        src: "/placeholder.svg?height=400&width=600",
        alt: "Ancient manuscript with mysterious symbols",
        caption: "The manuscript as discovered, showing intricate astronomical calculations",
      },
      {
        src: "/placeholder.svg?height=400&width=600",
        alt: "Diagram from the manuscript",
        caption: "Detailed diagram showing celestial alignments",
      },
    ],
  }

  // Sample download cards
  const downloadCards = [
    {
      title: "Research Paper",
      description: "Complete analysis of the manuscript findings",
      image: "/placeholder.svg?height=200&width=300",
      fileName: "research-paper.pdf",
    },
    {
      title: "High-Res Images",
      description: "Detailed scans of the original manuscript",
      image: "/placeholder.svg?height=200&width=300",
      fileName: "manuscript-scans.zip",
    },
    {
      title: "Translation Notes",
      description: "Working translation with expert annotations",
      image: "/placeholder.svg?height=200&width=300",
      fileName: "translation-notes.pdf",
    },
    {
      title: "Historical Context",
      description: "Background on the era and related discoveries",
      image: "/placeholder.svg?height=200&width=300",
      fileName: "historical-context.pdf",
    },
  ]

  return (
    <main className="min-h-screen bg-[#f5f1e6]">
      <Navbar />
      <div className="container mx-auto px-4 py-8">
        <ArticleContent article={article} />

        <section className="my-16">
          <h2 className="text-3xl font-serif text-[#8b5a2b] mb-8 text-center">Related Resources</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {downloadCards.map((card, index) => (
              <DownloadCard key={index} card={card} />
            ))}
          </div>
        </section>
      </div>
      <Footer />
    </main>
  )
}
