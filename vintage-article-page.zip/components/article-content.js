import Image from "next/image"

export default function ArticleContent({ article }) {
  return (
    <article className="max-w-4xl mx-auto bg-[#f9f6f0] p-8 rounded-lg shadow-md border border-[#e0d5c1]">
      <div className="mb-8 text-center">
        <h1 className="text-4xl md:text-5xl font-serif text-[#8b5a2b] mb-4">{article.title}</h1>
        <div className="text-[#8b5a2b]/70 italic">
          By {article.author} • {article.date}
        </div>
      </div>

      <div className="prose prose-lg max-w-none">
        {article.content.map((paragraph, index) => (
          <p key={index} className="mb-6 text-[#5c3c1d] leading-relaxed">
            {paragraph}
          </p>
        ))}

        {article.images.map((image, index) => (
          <figure key={index} className="my-8">
            <div className="relative h-[400px] w-full bg-[#e8d9c0] p-2 border border-[#c9b18c]">
              <Image src={image.src || "/placeholder.svg"} alt={image.alt} fill className="object-contain" />
            </div>
            <figcaption className="mt-2 text-center text-sm text-[#8b5a2b] italic">{image.caption}</figcaption>
          </figure>
        ))}
      </div>
    </article>
  )
}
