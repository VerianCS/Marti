import Link from "next/link"

export default function Footer() {
  return (
    <footer className="bg-[#e8d9c0] border-t border-[#c9b18c] py-8">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <h3 className="font-serif text-xl text-[#8b5a2b] mb-4">Antiquarian Archives</h3>
            <p className="text-[#5c3c1d] text-sm">
              Preserving the past, illuminating the future. Our collection spans centuries of human knowledge and
              discovery.
            </p>
          </div>

          <div>
            <h3 className="font-serif text-xl text-[#8b5a2b] mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <Link href="#" className="text-[#5c3c1d] hover:text-[#8b5a2b] text-sm">
                  Terms of Service
                </Link>
              </li>
              <li>
                <Link href="#" className="text-[#5c3c1d] hover:text-[#8b5a2b] text-sm">
                  Privacy Policy
                </Link>
              </li>
              <li>
                <Link href="#" className="text-[#5c3c1d] hover:text-[#8b5a2b] text-sm">
                  Contact Us
                </Link>
              </li>
              <li>
                <Link href="#" className="text-[#5c3c1d] hover:text-[#8b5a2b] text-sm">
                  Submissions
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="font-serif text-xl text-[#8b5a2b] mb-4">Subscribe</h3>
            <p className="text-[#5c3c1d] text-sm mb-4">
              Join our newsletter to receive updates on new discoveries and articles.
            </p>
            <div className="flex">
              <input
                type="email"
                placeholder="Your email"
                className="flex-1 px-3 py-2 bg-[#f9f6f0] border border-[#c9b18c] rounded-l focus:outline-none"
              />
              <button className="bg-[#8b5a2b] hover:bg-[#5c3c1d] text-white px-4 py-2 rounded-r transition-colors">
                Subscribe
              </button>
            </div>
          </div>
        </div>

        <div className="mt-8 pt-6 border-t border-[#c9b18c] text-center text-[#5c3c1d] text-sm">
          © {new Date().getFullYear()} Antiquarian Archives. All rights reserved.
        </div>
      </div>
    </footer>
  )
}
